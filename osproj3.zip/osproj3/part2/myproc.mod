/home/vboxuser/osproj3/part2/myproc.o
