savedcmd_/home/vboxuser/osproj3/part2/myproc.mod := printf '%s\n'   myproc.o | awk '!x[$$0]++ { print("/home/vboxuser/osproj3/part2/"$$0) }' > /home/vboxuser/osproj3/part2/myproc.mod
