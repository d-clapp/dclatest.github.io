savedcmd_/home/vboxuser/osproj3/part2/modules.order := {   echo /home/vboxuser/osproj3/part2/myproc.o; :; } > /home/vboxuser/osproj3/part2/modules.order
