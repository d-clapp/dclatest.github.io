/home/vboxuser/osproj3/part1/new_module.o
